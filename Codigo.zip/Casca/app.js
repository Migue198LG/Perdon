const express = require("express");
const mysql = require("mysql2/promise");
var bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
var app = express();

let port = 8080;
let userId = null;




const con = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'n0m3l0',
    database: 'mech2',
});


// con.connect((err) => {
//     if (err) {
//         console.log("No se conectó a la base de datos");
//         return;
//     }
//     console.log("Conectado a la base de datos");
// });

// Configurar Express para servir archivos estáticos
app.use('/js', express.static(path.join(__dirname, 'public', 'js')));
app.use('/css', express.static(path.join(__dirname, 'public', 'css')));
app.use('/imgs', express.static(path.join(__dirname,  'public', 'imgs')));



// Configuración de sesión
app.use(session({
    secret: 'clave_secreta',
    resave: false,
    saveUninitialized: true
}));

app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));



function verificarAutenticacion(req, res, next) {
    if (req.session && req.session.userId) {
        return next();
    } else {
        console.log('Redirigiendo a iniciar sesión');
        res.redirect('/iniciar-sesion');
    }
}


app.get('/cliente/:archivo', verificarAutenticacion, (req, res) => {
    const archivo = req.params.archivo;
    res.sendFile(path.join(__dirname, 'public', 'cliente', archivo));
});

app.get('/mecanico/:archivo', verificarAutenticacion, (req, res) => {
    const archivo = req.params.archivo;
    res.sendFile(path.join(__dirname, 'public', 'mecanico', archivo));
});

// Rutas de sesión y registro
app.get('/verificar-sesion', (req, res) => {
    if (req.session && req.session.usuario) {
        res.status(200).json({ autenticado: true });
    } else {
        res.status(401).json({ autenticado: false });
    }
});

app.post('/iniciarsesion', async (req, res) => {
    const { correo_i, contra_i } = req.body;

    if (!correo_i || !contra_i) {
        return res.status(400).json({ error: "Por favor, completa todos los campos." });
    }

    try {
        const query = 'SELECT id_persona, correo, tipo_usuario FROM persona WHERE correo = ? AND contraseña = ?';
        const [respuesta] = await con.query(query, [correo_i, contra_i]);

        if (respuesta.length > 0) {
            req.session.userId = respuesta[0].id_persona;
            const redirectTo = respuesta[0].tipo_usuario === 'mecanico' ? '/mecanico' : '/cliente';
            res.status(200).json({ message: "Inicio de sesión exitoso", redirectTo });
        } else {
            res.status(400).json({ error: "Credenciales incorrectas" });
        }
    } catch (err) {
        console.error('ERROR: ', err);
        res.status(500).json({ error: "Error al consultar la base de datos" });
    }
});

app.post('/registrarus', (req, res) => {
    const correo_i = req.body.correo;
    const contra_i = req.body.contra;
    const usuario_i = req.body.usuario;
    const rol_i = req.body.rol; // Se recibe como 'cliente' o 'mecanico'

    if (!correo_i || !contra_i || !usuario_i || !rol_i) {
        return res.status(400).json({ error: "Todos los campos son requeridos." });
    }

    // Verificar si el correo ya está registrado
    con.query('SELECT * FROM persona WHERE correo = ?', [correo_i], (err, result) => {
        if (err) {
            console.log("ERROR: ", err);
            return res.status(500).json({ error: 'Error al consultar la base de datos' });
        }

        if (result.length > 0) {
            return res.status(400).json({ error: 'El correo ya está registrado' });
        }

        // Insertar el nuevo usuario en la base de datos
        const query = 'INSERT INTO persona (usuario, correo, contraseña, tipo_usuario) VALUES (?, ?, ?, ?)';
        con.query(query, [usuario_i, correo_i, contra_i, rol_i], (err, result) => {
            if (err) {
                console.log("ERROR: ", err);
                return res.status(500).json({ error: 'Error al registrar el usuario' });
            }

            // Responder con éxito
            res.status(200).json({ success: true });
        });
    });
});

app.post('/cerrarsesion', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error al destruir la sesión:', err);
            return res.status(500).json({ success: false, error: "Error al cerrar sesión" });
        }
        res.clearCookie('connect.sid'); // Esto elimina la cookie de sesión
        res.status(200).json({ success: true, message: "Sesión cerrada correctamente" });
    });
});

// Rutas públicas
app.get('/dashboard', (req, res) => {
    if (req.session.userId) {
        res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
    } else {
        res.redirect('/iniciar-sesion');
    }
});

app.get('/iniciar-sesion', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/mecanico', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'mecanico', 'inicio_mecanico.html'));
});

app.get('/cliente', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'cliente','inicio_cliente.html'));
});

// Middleware que redirige a login si no está autenticado
app.use((req, res, next) => {
    const rutasPublicas = ['/iniciar-sesion', '/verificar-sesion', '/registrarus', '/cerrarsesion'];
    if (!rutasPublicas.includes(req.path) && (!req.session || !req.session.userId)) {
        console.log('Redirigiendo a iniciar sesión desde middleware');
        return res.redirect('/iniciar-sesion');
    }
    next();
});

app.get('/scr_tabla', async (req, res) => {
    try {
        const tipoUsuario = req.query.tipo || 'mecanico'; // 'mecanico' o 'cliente'

        let query;
        // if (tipoUsuario === 'mecanico') {
//             query = `SELECT 
//     r.fecha, 
//     r.bitacora AS descripcion_cambio, 
//     m.correo AS correo_mecanico,
//     v.placa 
// FROM 
//     registro r
// JOIN persona m ON r.id_persona = m.id_persona  -- Relacionamos con la persona para obtener el correo del mecánico
// JOIN vehiculo v ON r.id_vehiculo = v.id_vehiculo  -- Relacionamos con la tabla vehiculo para obtener la placa
// WHERE 
//     v.correo_u = 'usu@gmail.com'  -- Filtra por el correo del cliente específico (cliente asociado al vehículo)
//     AND m.tipo_usuario = 'mecanico'  -- Asegura que la persona sea un mecánico
// ORDER BY r.fecha;  -- Ordena por fecha para mostrar los registros más recientes primero
// `;
//         } else if (tipoUsuario === 'cliente') {
            query = `SELECT r.id_vehiculo, c.correo, r.placa
                     FROM registro r
                     JOIN persona c ON r.id_persona = c.id_persona
                     WHERE c.tipo_usuario = 'cliente'`; // Aquí seleccionamos solo los clientes
        // } else {
            return res.status(400).json({ error: 'Tipo de usuario no válido' });
        // }

        const [rows] = await con.query(query);

        console.log(rows); // Verifica los datos antes de enviarlos
        res.json(rows); // Envía la respuesta al cliente
    } catch (error) {
        console.error('Error en la consulta:', error);
        res.status(500).json({ error: 'Error en la consulta de la base de datos' });
    }
});







app.get('/consulta/:placa', async (req, res) => {
    const { placa } = req.params;
    try {
        const query = "SELECT r.fecha, r.bitacora AS descripcion_cambio FROM registro r JOIN vehiculo v ON r.id_vehiculo = v.id_vehiculo WHERE v.placa = ?";
        const [rows] = await con.query(query, [placa]); // Ejecuta la consulta
        res.json(rows); // Responde con los resultados
    } catch (err) {
        console.error("Error al ejecutar la consulta SQL:", err);
        res.status(500).json({ error: "Error en la consulta SQL." });
    }
});






app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);

    
});
